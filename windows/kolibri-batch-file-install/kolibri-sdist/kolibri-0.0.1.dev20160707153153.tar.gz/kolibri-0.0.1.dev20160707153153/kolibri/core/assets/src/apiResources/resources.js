module.exports = [
  require('./classroom'),
  require('./contentNode'),
  require('./facilityUser'),
  require('./learnerGroup'),
  require('./membership'),
];
