from __future__ import absolute_import, print_function, unicode_literals

from kolibri.plugins import registry

registry.initialize()
