/* eslint-disable */
module.exports = {
  classroom: [
    {
      "id": 2,
      "name": "Foo",
      "parent": 1
    },
    {
      "id": 3,
      "name": "Bar",
      "parent": 1
    }
  ],
  learnergroup: [
    {
      "id": 4,
      "name": "Foo's group",
      "parent": 2},
    {
      "id": 5,
      "name": "Bar's group",
      "parent": 3
    }
  ],
  facilityuser: [
    {
      "id": 1,
      "username": "mike",
      "first_name": "mike",
      "last_name": "gallaspy",
      "facility": 1
    },
    {
      "id": 2,
      "username": "jessica",
      "first_name": "Jessica",
      "last_name": "Aceret",
      "facility": 1
    },
    {
      "id": 3,
      "username": "jduck",
      "first_name": "John",
      "last_name": "Duck",
      "facility": 1
    }
  ],
  membership: [
    {
      "id": 1,
      "user": 1,
      "collection": 2
    },
    {
      "id": 2,
      "user": 1,
      "collection": 4
    },
    {
      "id": 3,
      "user": 2,
      "collection": 2
    },
    {
      "id": 4,
      "user": 3,
      "collection": 5
    }
  ],
};
