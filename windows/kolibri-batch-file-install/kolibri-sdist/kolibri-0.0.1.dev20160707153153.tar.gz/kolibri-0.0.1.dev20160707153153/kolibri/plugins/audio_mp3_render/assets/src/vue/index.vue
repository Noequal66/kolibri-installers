<template>

  <audio autoplay=true src='https://freemusicarchive.org/music/download/8a46d5ff69d7c426d2a0a6854d96a683dec17802' controls=true>
  </audio>

</template>


<script>

  module.exports = {};

</script>


<style lang="stylus" scoped></style>
