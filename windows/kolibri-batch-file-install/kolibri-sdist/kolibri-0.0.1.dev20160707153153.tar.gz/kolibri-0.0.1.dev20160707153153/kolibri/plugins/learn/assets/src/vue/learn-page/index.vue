<template>

  <div>
    TODO
  </div>

</template>


<script>

  module.exports = {
    components: {
      'content-card': require('../content-card'),
    },
  };

</script>


<style lang="stylus" scoped></style>
