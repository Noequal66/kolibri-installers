<template>

  <div>
    <h2>Scratchpad</h2>
    <p>Use this page for in-progress component prototyping.</p>
  </div>

</template>


<script>

  module.exports = {
  };

</script>


<style lang="stylus" scoped>

  @require '~core-theme.styl'

</style>
